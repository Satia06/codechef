'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
days_per_month=(31,28,31,30,31,30,31,31,30,31,30,31)

def check_leap_year(year):
    if year%4==0:
        if year%100==0:
            if year%400==400:
                return True
            else:
                return False
        else:
            return True
    return False
    
def check_even(day):
    return True if day%2==0 else False


t=input()
t=int(t)
    
for _in range(t):
    year,month,day=input().split(':')
    year,month,day=int(year),int(month),int(day)
    leap_check=check_leap_year(year)
    even_check=check_even(day)
    count=0
    if leap_check:
        if even_check:
            if days_per_month[month-1]==30:
                count=(30-day)//2+15+1
            else:
                if days_per_month[month-1]+1==29:
                    count=(29-day)//2+1
                else:
                   count=(days_per_month[month-1]-day)//2+1
        else:
            if days_per_month[month-1]==30: 
                count=(30-day)//2+16+1
            else:
                
                if days_per_month[month-1]+1==29:
                    count=(29-day)//2+16+1
                else:
                    count=(days_per_month[month-1]-day)//2+1
    else:
        if even_check:
            if days_per_month[month-1]==30:
                count=(30-day)//2+15+1
            elif days_per_month[month-1]==28:
                count=(28-day)//2+15+1
            else:
                count=(days_per_month[month-1]-day)//2+1
                
        else:
            if days_per_month[month-1]==30:
                count=(30-day)//2+16+1
            elif days_per_month[month-1]==28:
                count=(28-day)//2+16+1
            else:
                count=(days_per_month[month-1]-day)//2+1
                
print(count,"\n")            
