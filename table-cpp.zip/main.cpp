'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

#include<iostream>
#include<bits/stdc++.h>
using namesppace std;


void table_of(int N)
{
    int result;
    for(int i=1;i<=10;i++)
    {
        result = N*i;
        cout<<result<<endl;
    }
}

int main
{
    int N;
    cin>>N;
    table_of(N);
    return 0;
    
}


